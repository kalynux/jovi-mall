;===============================================================================
;  claude_auto_allow_v3.ahk  —  AutoHotkey v2
;
;  Auto-clicks the blue "Yes" / "Allow" button of Claude Code permission
;  prompts across ALL open VS Code windows.
;
;  WHAT WAS ACTUALLY WRONG (found via your Ctrl+F9 report + screenshot)
;  --------------------------------------------------------------------
;  * Your button's real color is 0x0F6DAC — and your calibration captured it
;    correctly. Hover vs non-hover is the SAME color (verified pixel-by-pixel
;    from your screenshot), so hover was not the issue.
;  * The bug: tolerance 60 was so loose that the tiny blue "Update" badge in
;    VS Code's TITLE BAR (your report: pixel at 1420,8, runWidth 11-21)
;    matched every candidate color, along with blue syntax highlighting.
;    The detector only skipped 6 false positives before giving up — it never
;    reached the real button lower in the window.
;
;  FIXES IN v3
;  -----------
;  1. IMAGE SEARCH FIRST (your suggestion). A reference picture of the real
;     "1 Yes" button — cropped from YOUR screenshot — ships next to this
;     script as btn_ref_yes.png. ImageSearch looks for that exact pattern
;     (blue bar + white text), which has essentially zero false positives
;     and is fast. You can drop additional reference crops in the same
;     folder named btn_ref_*.png (e.g. a crop of an "Allow" button) and
;     they are all used automatically.
;  2. Color-run detection kept as FALLBACK, but with tight tolerance 30
;     (excludes the title-bar Update badge, whose blue differs by 40) and
;     up to 25 false-positive skips instead of 6.
;  3. Default primary color is now YOUR measured 0x0F6DAC.
;  4. HOVER-SAFE CALIBRATION: Ctrl+Alt+P now remembers the position under
;     your mouse, MOVES THE MOUSE AWAY, waits for any hover effect to fade,
;     and only then samples the pixel — so it always captures the resting
;     color.
;  5. Ctrl+F9 debug scan now walks past false positives exactly like the
;     real detector and lists EVERY candidate it inspected, plus the
;     ImageSearch result — no more misleading single-hit reports.
;
;  HOTKEYS (global — they work even mid-scan while the mouse is moving)
;  --------------------------------------------------------------------
;    F8  or  Pause    pause / resume            Ctrl+F8   quit
;    Ctrl+F9          debug-scan active window  Ctrl+Alt+P  calibrate color
;===============================================================================

#Requires AutoHotkey v2.0
#SingleInstance Force

if !DllCall("SetProcessDpiAwarenessContext", "ptr", -4)   ; per-monitor DPI v2
    DllCall("SetProcessDPIAware")                          ; fallback (old Win10)

CoordMode "Pixel", "Screen"
CoordMode "Mouse", "Screen"
SendMode "Input"

;-------------------------------------------------------------------------------
; CONFIGURATION
;-------------------------------------------------------------------------------
INI_FILE          := A_ScriptDir "\claude_auto_allow.ini"

; Primary/default button colors. YOUR measured color first (0x0F6DAC, from
; the screenshot you provided — identical hovered and not). A calibrated
; color from Ctrl+Alt+P (stored in the .ini) is inserted before these.
DEFAULT_COLORS    := [0x0F6DAC, 0x0078D4]

BTN_VARIATION     := 30     ; TIGHT per-channel tolerance. 30 accepts the
                            ; slight hover shade (diff <= 28) but rejects the
                            ; title-bar Update badge (blue-channel diff 40).
IMG_VARIATION     := 40     ; shade tolerance for ImageSearch reference pics
MIN_BUTTON_WIDTH  := 120    ; blue run must be at least this wide (px)
MIN_BUTTON_HEIGHT := 8      ; ...and this tall at its midpoint (px)
MAX_SKIPS         := 25     ; false positives to walk past per color (was 6!)

CHECK_INTERVAL_MS  := 2500
CLICK_COOLDOWN_MS  := 4000
ACTIVATE_SETTLE_MS := 300
RESTORE_MINIMIZED  := false
RESTORE_FOCUS      := true
LOG_CLICKS         := true

;-------------------------------------------------------------------------------
; STATE
;-------------------------------------------------------------------------------
paused    := false
cooldown  := Map()
colorList := LoadColors()
refImages := LoadRefImages()    ; every btn_ref_*.png next to the script

TraySetIcon "shell32.dll", 45
UpdateBadge("RUNNING (" refImages.Length " ref image(s), "
    . colorList.Length " color(s))")
SetTimer ScanAllVSCodeWindows, CHECK_INTERVAL_MS

UpdateBadge(text) {
    ToolTip "Claude auto-Allow: " text "   [F8 pause | Ctrl+F8 quit]",
        A_ScreenWidth - 560, 8, 20
}

;-------------------------------------------------------------------------------
; MAIN LOOP
;-------------------------------------------------------------------------------
ScanAllVSCodeWindows() {
    global paused, cooldown
    if paused
        return
    vscodeWindows := WinGetList("ahk_exe Code.exe")
    if vscodeWindows.Length = 0
        return

    prevActive := 0
    try prevActive := WinGetID("A")
    MouseGetPos &prevMouseX, &prevMouseY

    for hwnd in vscodeWindows {
        if paused
            break
        if cooldown.Has(hwnd) && (A_TickCount - cooldown[hwnd] < CLICK_COOLDOWN_MS)
            continue
        if WinGetMinMax(hwnd) = -1 {
            if !RESTORE_MINIMIZED
                continue
            WinRestore hwnd
        }
        try {
            WinActivate hwnd
            if !WinWaitActive(hwnd, , 1)
                continue
        } catch
            continue
        Sleep ACTIVATE_SETTLE_MS
        UpdateBadge("SCANNING window " A_Index "/" vscodeWindows.Length)

        WinGetClientPos &cx, &cy, &cw, &ch, hwnd
        if (cw < 200 || ch < 200)
            continue

        found := false, btnX := 0, btnY := 0, how := ""

        ; ---- METHOD 1: ImageSearch with your reference button picture(s) ----
        for ref in refImages {
            if ImageSearch(&fx, &fy, cx, cy, cx + cw - 1, cy + ch - 1,
                           "*" IMG_VARIATION " " ref.path) {
                ; Click inside the matched pattern (its center).
                btnX := fx + ref.w // 2
                btnY := fy + ref.h // 2
                found := true, how := "image:" ref.name
                break
            }
        }

        ; ---- METHOD 2 (fallback): wide-blue-bar color detection ----
        if !found
            && FindAllowButton(cx, cy, cx + cw - 1, cy + ch - 1, &btnX, &btnY, &mc) {
            found := true, how := "color:" Format("0x{:06X}", mc)
        }

        if found {
            ClickButton(btnX, btnY)
            cooldown[hwnd] := A_TickCount
            UpdateBadge("CLICKED ✔ (" how ")")
            title := ""
            try title := WinGetTitle(hwnd)
            if LOG_CLICKS
                FileAppend FormatTime(, "yyyy-MM-dd HH:mm:ss") " | clicked ("
                    . btnX "," btnY ") via " how " | " title "`n",
                    A_ScriptDir "\claude_auto_allow.log"
            Sleep 400
        }
    }

    if RESTORE_FOCUS && !paused {
        MouseMove prevMouseX, prevMouseY, 0
        if prevActive && WinExist(prevActive)
            try WinActivate prevActive
    }
    UpdateBadge(paused ? "PAUSED" : "RUNNING")
}

;-------------------------------------------------------------------------------
; CLICKING — Electron-proof: move -> settle -> click -> verify -> retry once.
;-------------------------------------------------------------------------------
ClickButton(x, y) {
    before := PixelGetColor(x, y)
    MouseMove x, y, 5
    Sleep 120
    Click "Left"
    Sleep 500
    ; If the pixel still looks like the (possibly hover-shaded) button, the
    ; click was swallowed by Electron's focus handling — click once more.
    if ColorMatchesAny(PixelGetColor(x, y)) || PixelGetColor(x, y) = before {
        Click "Left"
        Sleep 300
    }
}

;-------------------------------------------------------------------------------
; COLOR-RUN DETECTION (fallback method)
;-------------------------------------------------------------------------------
FindAllowButton(x1, y1, x2, y2, &outX, &outY, &outColor) {
    for c in colorList {
        searchTop := y1
        loop MAX_SKIPS {
            if !PixelSearch(&fx, &fy, x1, searchTop, x2, y2, c, BTN_VARIATION)
                break
            runEnd := fx, x := fx
            while (x <= x2 && ColorMatches(PixelGetColor(x, fy), c))
                runEnd := x, x += 10
            while (runEnd + 1 <= x2 && ColorMatches(PixelGetColor(runEnd + 1, fy), c))
                runEnd += 1
            runWidth := runEnd - fx + 1

            midX := fx + runWidth // 2
            thickness := 1, yDown := fy + 1
            while (yDown <= y2 && ColorMatches(PixelGetColor(midX, yDown), c))
                thickness += 1, yDown += 1

            if (runWidth >= MIN_BUTTON_WIDTH && thickness >= MIN_BUTTON_HEIGHT) {
                outX := midX, outY := fy + thickness // 2, outColor := c
                return true
            }
            searchTop := fy + thickness + 2
            if (searchTop >= y2)
                break
        }
    }
    return false
}

ColorMatches(c, target) {
    return Abs(((c >> 16) & 0xFF) - ((target >> 16) & 0xFF)) <= BTN_VARIATION
        && Abs(((c >> 8)  & 0xFF) - ((target >> 8)  & 0xFF)) <= BTN_VARIATION
        && Abs((c & 0xFF)         - (target & 0xFF))         <= BTN_VARIATION
}
ColorMatchesAny(c) {
    for t in colorList
        if ColorMatches(c, t)
            return true
    return false
}

;-------------------------------------------------------------------------------
; LOADERS
;-------------------------------------------------------------------------------
LoadColors() {
    list := []
    saved := IniRead(INI_FILE, "calibration", "btn_color", "")
    if (saved != "")
        list.Push(Integer(saved))
    for c in DEFAULT_COLORS
        list.Push(c)
    return list
}

; Collect btn_ref_*.png files sitting next to the script and read each
; image's width/height (needed to click its center). Reading dimensions uses
; a temporary GUI picture control — no external libraries required.
LoadRefImages() {
    imgs := []
    loop Files A_ScriptDir "\btn_ref_*.png" {
        w := 0, h := 0
        try {
            g := Gui()
            pic := g.Add("Picture", , A_LoopFileFullPath)
            pic.GetPos(, , &w, &h)
            g.Destroy()
        }
        if (w && h)
            imgs.Push({path: A_LoopFileFullPath, name: A_LoopFileName, w: w, h: h})
    }
    return imgs
}

;-------------------------------------------------------------------------------
; HOTKEYS
;-------------------------------------------------------------------------------
TogglePause(*) {
    global paused
    paused := !paused
    UpdateBadge(paused ? "PAUSED" : "RUNNING")
    TrayTip "Claude auto-Allow", paused ? "Paused" : "Resumed", 1
}
F8::TogglePause()
Pause::TogglePause()

^F8:: {
    ToolTip , , , 20
    TrayTip "Claude auto-Allow", "Exiting", 1
    Sleep 300
    ExitApp
}

; Ctrl+Alt+P — HOVER-SAFE calibration:
;   1) remembers the point under your mouse
;   2) moves the mouse 250 px away so any hover highlight fades
;   3) waits, then samples the ORIGINAL point -> true resting color
^!p:: {
    global colorList
    MouseGetPos &mx, &my
    MouseMove mx, my - 250 > 0 ? my - 250 : my + 250, 0   ; step off the button
    Sleep 700                                              ; hover effect fades
    c := PixelGetColor(mx, my)
    hex := Format("0x{:06X}", c)
    IniWrite hex, INI_FILE, "calibration", "btn_color"
    colorList := LoadColors()
    A_Clipboard := hex
    MsgBox "Resting color at " mx "," my " = " hex "`n(sampled after moving the"
         . " mouse away, so no hover tint)`n`nSaved — used first from now on.",
        "Calibrated ✔", "T6"
}

; Ctrl+F9 — exhaustive debug scan of the ACTIVE window. Mirrors the real
; detector: reports the ImageSearch result and EVERY color-run candidate it
; walked past, so you can see exactly why something matched or didn't.
^F9:: {
    hwnd := WinGetID("A")
    WinGetClientPos &cx, &cy, &cw, &ch, hwnd
    x2 := cx + cw - 1, y2 := cy + ch - 1
    report := "Window: " WinGetTitle(hwnd) "`nClient: " cx "," cy "  " cw "x" ch "`n`n"

    report .= "— ImageSearch (" refImages.Length " ref image(s)) —`n"
    if refImages.Length = 0
        report .= "  (none found — put btn_ref_yes.png next to the script!)`n"
    for ref in refImages
        report .= "  " ref.name " (" ref.w "x" ref.h "): "
            . (ImageSearch(&fx, &fy, cx, cy, x2, y2, "*" IMG_VARIATION " " ref.path)
               ? "FOUND at " fx "," fy "  => WOULD CLICK ✔" : "not found") "`n"

    report .= "`n— Color-run fallback (tolerance " BTN_VARIATION ") —`n"
    for c in colorList {
        report .= Format("0x{:06X}", c) ":`n"
        searchTop := cy, hits := 0
        loop MAX_SKIPS {
            if !PixelSearch(&fx, &fy, cx, searchTop, x2, y2, c, BTN_VARIATION) {
                if hits = 0
                    report .= "    no matching pixel anywhere`n"
                break
            }
            hits += 1
            runEnd := fx, x := fx
            while (x <= x2 && ColorMatches(PixelGetColor(x, fy), c))
                runEnd := x, x += 10
            while (runEnd + 1 <= x2 && ColorMatches(PixelGetColor(runEnd + 1, fy), c))
                runEnd += 1
            runWidth := runEnd - fx + 1
            midX := fx + runWidth // 2
            thickness := 1, yDown := fy + 1
            while (yDown <= y2 && ColorMatches(PixelGetColor(midX, yDown), c))
                thickness += 1, yDown += 1
            pass := (runWidth >= MIN_BUTTON_WIDTH && thickness >= MIN_BUTTON_HEIGHT)
            report .= "    at " fx "," fy "  w=" runWidth " h=" thickness
                . "  => " (pass ? "WOULD CLICK ✔`n" : "skip`n")
            if pass
                break
            searchTop := fy + thickness + 2
            if (searchTop >= y2)
                break
        }
    }
    MsgBox report, "Debug scan (exhaustive)", "T60"
}
