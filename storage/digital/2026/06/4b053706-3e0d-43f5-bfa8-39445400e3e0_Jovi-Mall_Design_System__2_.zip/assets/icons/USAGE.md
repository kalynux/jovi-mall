# Icon usage — Lucide

Jovi-Mall uses [Lucide](https://lucide.dev) icons exclusively. This is enforced in `components.json` (`iconLibrary: "lucide"`) and observed across every surface of the source codebase.

## How to use

In React: `npm i lucide-react`, then `import { ShoppingCart } from 'lucide-react'`.

In HTML prototypes: load via CDN, then use the `<i data-lucide="...">` attribute and call `lucide.createIcons()`.

```html
<script src="https://unpkg.com/lucide@latest"></script>
<i data-lucide="shopping-cart" class="w-4 h-4"></i>
<script>lucide.createIcons();</script>
```

## Size conventions

| Context | Size |
| --- | --- |
| Tiny badge / inline glyph | `w-3 h-3` (12px) |
| Buttons, dropdown rows, inputs | `w-4 h-4` (16px) ← most common |
| Sidebar nav, metric tile, page-level | `w-5 h-5` (20px) |
| Empty states, modal heroes | `w-8 h-8` to `w-16 h-16` |

Stroke is the Lucide default (2px), inherits `currentColor`. No filled variants.

## Mapping

See README.md → ICONOGRAPHY for the dashboard's icon-name → surface mapping.
